# BackItUp! #
This program backs the current directory recursively into a hidden .backup/ directory. It can also restore the contents of the directory.

# Usage
Compiling
`make`

Backing up the current directory
`./BackItUp`

Restoring the backed up files
`./BackItUp -r`

# Authors #

Tyler Higgins  
Julian Keller  
Jacob Pugsley  

